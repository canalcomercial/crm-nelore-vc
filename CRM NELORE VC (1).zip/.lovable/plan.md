# Plano de Responsividade — CRM Nelore VC

Objetivo: tornar todo o CRM utilizável e agradável em 4 faixas de tela — mobile (≤640px), tablet (641–1024px), notebook (1025–1440px) e desktop (>1440px). Hoje o layout é otimizado só para telas grandes; sidebar fixa, kanban horizontal, tabelas largas e diálogos rígidos quebram em telas menores.

## Faixas alvo (breakpoints Tailwind)

```text
mobile   : base   (< 640px)   sm:
tablet   : md    (≥ 768px)
notebook : lg    (≥ 1024px)
desktop  : xl    (≥ 1280px)
wide     : 2xl   (≥ 1536px)
```

## 1. Shell e navegação (AppShell + Sidebar + Topbar)

Problema: `Sidebar` é fixa em 52px vertical e `AppShell` usa `flex h-screen` — em mobile ocupa área útil e não há menu recolhível.

- Sidebar vira **bottom tab bar** em mobile (`< md`): mesmos ícones, altura 56px, fixa embaixo. Badge de tarefas mantido.
- Em tablet (`md`–`lg`): sidebar lateral compacta (48px), sem labels.
- Em notebook/desktop (`lg+`): sidebar 56–64px com tooltips (comportamento atual, levemente maior).
- `AppShell` passa a usar `min-h-dvh` (não `h-screen`) para respeitar barras de navegador móvel; adiciona `pb-[56px] md:pb-0` quando bottom bar ativa.
- Topbar: título encolhe, ações viram menu "⋯" em `< sm`; botão "Novo lead" continua visível como ícone.

## 2. Funis / Kanban (`src/pages/Funis.tsx`, `KanbanColumn`)

Problema: colunas de 280px em linha estouram horizontalmente; filtros e busca ocupam uma linha só e quebram.

- **Mobile:** vista em "carrossel de etapas" — uma coluna por vez, largura `w-[calc(100vw-2rem)]`, com chips de etapa scrolláveis no topo para pular entre elas (scroll-snap). Card do lead mais compacto, fontes 12–13px.
- **Tablet:** 2 colunas visíveis com scroll horizontal + snap.
- **Notebook/Desktop:** comportamento atual, colunas 280px.
- Barra de filtros do funil vira **stack vertical** em `< md`: linha 1 pills de funil (scroll-x), linha 2 busca full width, linha 3 select vendedor + botão editar.
- Dropdown de busca: largura `w-[calc(100vw-2rem)] max-w-sm` em mobile.

## 3. LeadPanel e diálogos

Problema: `LeadPanel`, `NovoLeadDialog`, `EmitirContratoDialog`, `ContratoDialog`, `FollowUpDialog`, `VendaDialog`, `FunilEditor` usam larguras fixas (`max-w-2xl` etc.) e não são full-screen em mobile.

- Padrão global: em `< md` todos os `Dialog`/`Sheet` recebem `h-[100dvh] w-screen max-w-none rounded-none`. Em `md+` mantêm o tamanho atual.
- `LeadPanel` (lateral) vira drawer **bottom-sheet** com 92dvh em mobile; conteúdo com `overflow-y-auto` e ações "salvar/fechar" fixas no rodapé.
- Formulários internos: campos passam de `grid-cols-2` para `grid-cols-1` em `< sm`; labels acima do input.

## 4. Tabelas e listas densas

Páginas afetadas: `BancoContatos`, `Vendas`, `Tarefas`, `Equipe`, `Disparos`, `ImportarLeads`, `AdminContratos` (`ListaContratos`), `AdminCatalogo`.

- Estratégia dupla:
  - `md+`: tabela como está, com `overflow-x-auto` de segurança.
  - `< md`: transformar cada linha em **card empilhado** (`div` com título, subtítulo, meta e ações). Componente utilitário `<ResponsiveRow>` para padronizar.
- Colunas secundárias (data de criação, ID, etc.) escondidas em `sm` com `hidden md:table-cell`.
- Filtros topo das listas → `flex-wrap gap-2`, cada controle `w-full sm:w-auto`.

## 5. Página de Admin (tabs unificadas)

Problema: `Admin.tsx` tem muitas tabs (Marketing, Meta, Contratos, etc.) que estouram em mobile.

- `TabsList` com `overflow-x-auto scrollbar-thin` e `flex-nowrap`; cada `TabsTrigger` `shrink-0`.
- Em `< md`, opcionalmente trocar por um `Select` de seções (padrão iOS "segmented → dropdown").
- Cada editor interno (`SecoesEditor`, `TemaEditor`, `LayoutEditor`, `TemplateEditor`) revisado para `grid-cols-1 md:grid-cols-2` em vez de fixos.

## 6. Página pública (`PaginaComercial`, `Catalogo`, `AnimalDetalhe`)

Já foi otimizada parcialmente. Passe final:

- Grid de lotes: `grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4` (hoje varia).
- Hero: altura por `aspect-video` em `< md` e `aspect-[21/9]` em `md+`, título abaixo do vídeo.
- `AnimalDetalhe`: colunas de ficha/pedigree/genética empilham em `< lg`; sticky "Tenho interesse" no rodapé em mobile.
- Modais `LeadModal`/`AnimalModal` — já full-screen em mobile, apenas validar padding e safe-area (`pb-[env(safe-area-inset-bottom)]`).

## 7. Utilidades transversais

- Criar `src/styles/responsive.css` (ou seção em `index.css`) com helpers: `.safe-bottom`, `.scroll-snap-x`, `.card-row`.
- Trocar `h-screen` por `min-h-dvh` em todos os shells/páginas (grep programático).
- Fontes fluidas para títulos: `text-2xl md:text-3xl lg:text-4xl` padronizado em h1/h2 (via classes utilitárias, sem alterar tokens).
- Imagens: garantir `loading="lazy"` e `sizes` corretos em grids.

## Ordem de execução

1. Shell + Sidebar (bottom bar mobile) + Topbar.
2. Diálogos: padrão full-screen mobile em todos os `Dialog`/`Sheet`.
3. Funis / Kanban carrossel por etapa.
4. LeadPanel bottom-sheet.
5. Tabelas → cards empilhados em mobile (Banco, Vendas, Tarefas, Equipe, Disparos, Contratos, Catálogo).
6. Admin tabs scrolláveis + grids internos.
7. Página pública — passe de ajuste final.
8. QA por breakpoint (mobile 390, tablet 820, notebook 1366, desktop 1920) com Playwright screenshots.

## Fora de escopo

- Mudança de tokens de cor ou tipografia.
- Alterações de lógica de negócio, RLS, dados.
- Redesign visual — apenas layout responsivo.

## Detalhes técnicos

- Todo o CSS via classes Tailwind + tokens semânticos existentes (`bg-surface`, `border-border`, etc.).
- Nenhum novo pacote; usa `@dnd-kit` e shadcn já presentes.
- `Sheet` do shadcn para bottom-sheet do LeadPanel em mobile (mantém `Dialog` interno para o restante).
- Testes visuais: script Playwright em `/tmp/browser/responsive/` fazendo screenshots das rotas chave em 4 viewports.
